-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 15, 2018 at 01:00 AM
-- Server version: 10.1.8-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kanopoly_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `h_id` int(10) UNSIGNED NOT NULL,
  `staff_id` int(11) NOT NULL,
  `date_of_ap` varchar(250) NOT NULL,
  `type_of_ap` varchar(250) NOT NULL,
  `ap_detail` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`h_id`, `staff_id`, `date_of_ap`, `type_of_ap`, `ap_detail`) VALUES
(3, 4, 'khjojomol', 'ploooo', 'u8uuuuuuuuy'),
(4, 8, '22-02-2019', 'manager', 'manager in the company'),
(5, 9, '22-02-2019', 'manager', 'manager of the company'),
(6, 10, '22-02-2019', 'accountant', 'accountant of the company'),
(7, 11, '22-02-2019', 'supervisor', 'supervisor in the company'),
(8, 12, 'jhndknwkdn', 'jkahdiqhdih', 'hdhwidhih'),
(9, 13, 'knknknk', 'kjdfjeofj', 'ossudowdko'),
(10, 14, 'kjgoiejfioe', 'klsjdiwh', 'kssncisnhcikhn'),
(11, 15, 'kokokp', 'kpfkpkfp', 'wlkddpwwkdpdkwpdd'),
(12, 16, 'fwfqwfwf', 'wfwfwf', 'wfwfqfqf');

-- --------------------------------------------------------

--
-- Table structure for table `qualification`
--

CREATE TABLE `qualification` (
  `q_id` int(10) UNSIGNED NOT NULL,
  `q_detail` varchar(250) NOT NULL,
  `q_date` varchar(250) NOT NULL,
  `staff_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qualification`
--

INSERT INTO `qualification` (`q_id`, `q_detail`, `q_date`, `staff_id`) VALUES
(1, '22-12-2020', 'banker', 7),
(2, '22-12-2020', 'jober man', 4),
(3, '22-12-2020', 'developer', 8),
(4, 'Developer', '22-12-2020', 9),
(5, 'cooker', '22-12-2020', 10),
(6, 'HND', '22-12-2020', 11),
(7, 'ihdijdiwh', '22-12-2020', 12),
(8, 'ksjflmkl', '22-12-2020', 13),
(9, 'isjfieehi', '22-12-2020', 14),
(10, 'eflkefe', 'efefe', 15),
(11, 'wfwfdwd', 'wdwdwf', 16);

-- --------------------------------------------------------

--
-- Table structure for table `staffs`
--

CREATE TABLE `staffs` (
  `staff_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(250) NOT NULL,
  `dob` varchar(250) NOT NULL,
  `gender` varchar(250) NOT NULL,
  `home_addr` varchar(250) NOT NULL,
  `lga` varchar(250) NOT NULL,
  `state` varchar(250) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(250) NOT NULL,
  `nxt_of_kin` varchar(250) NOT NULL,
  `nxt_of_kin_addr` varchar(250) NOT NULL,
  `area_of_special` varchar(500) NOT NULL DEFAULT 'NILL',
  `member_of_pro_body` varchar(500) NOT NULL DEFAULT 'NILL'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staffs`
--

INSERT INTO `staffs` (`staff_id`, `name`, `dob`, `gender`, `home_addr`, `lga`, `state`, `phone`, `email`, `nxt_of_kin`, `nxt_of_kin_addr`, `area_of_special`, `member_of_pro_body`) VALUES
(8, 'umar abdull', '22-12-2017', 'Male', 'kabuga', 'dutse', 'kano', '0903t663636', 'oruma02@yahoo.com', 'sadiq abdull', 'yobe', '', ''),
(9, 'Aisha Abdull', '01-02-2016', 'Female', 'kabuga', 'ede', 'Niger', '0903t663636', 'aisha@gmail.com', 'mike udoh', 'red bricks', '', ''),
(10, 'amina sani', '03-11-2012', 'Female', 'dutse ma', 'ede', 'Niger', '08364637373', 'jamila@gmail.com', 'umar audu', 'kano naigeria', '', ''),
(11, 'hamza shehu', '01-02-2016', 'Male', 'elerin', 'baza', 'Niger', '090337382', 'hamz@gmail.com', 'usman abdull', 'red bricks', 'tailor', 'Nigerian Tailors Assoiciation');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`h_id`);

--
-- Indexes for table `qualification`
--
ALTER TABLE `qualification`
  ADD PRIMARY KEY (`q_id`);

--
-- Indexes for table `staffs`
--
ALTER TABLE `staffs`
  ADD PRIMARY KEY (`staff_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `h_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `qualification`
--
ALTER TABLE `qualification`
  MODIFY `q_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `staffs`
--
ALTER TABLE `staffs`
  MODIFY `staff_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
