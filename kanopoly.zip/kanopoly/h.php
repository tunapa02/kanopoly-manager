

<!-- including the nesessary files  the database connection and the page header  -->
<?php session_start();  ?>
<?php include('connect.php'); ?>
<?php include('includes/header.php');?>



<?php
 
   
	   //checking if a staff id exist
	  if(isset($_GET['staff_id']))
	  {        
	  	 $staff_id = $_GET['staff_id'];
      // echo $staff_id;
	  }	
	  else
	  {
	  	  header('Location: index.php');
	  }


    
     
	     //checking if the user input is set
      if(isset($_POST['h_date']) && isset($_POST['h_type']) && isset($_POST['h_detail']))
      {

           //checking if the user input is empty
      	   if(empty($_POST['h_date']) || empty($_POST['h_type']) || empty($_POST['h_detail']))
		   {
               //displaying the error message if the form is empty
		      	  $msg = '<div class="alert alert-danger" role="alert">All fields are required</div>';
		   }
		   else
		   {
		   	          //get the user input into the variable
		   	           $h_date   = $_POST['h_date'];
                   $h_type   = $_POST['h_type'];
                   $h_detail = $_POST['h_detail'];



                   
               
                   //making the query
                   $q = "INSERT INTO history(staff_id, date_of_ap, type_of_ap, ap_detail)VALUES('$staff_id', '$h_date', '$h_type', '$h_detail')";
                   $result = mysqli_query($dbcon, $q);
                   if($result)
                   {
                        
                        $_SESSION['succes_add'] = 1;
                        
                        //redirecting the user after succesfully adding a staff
                   	    header('Location: index.php');
                        exit();
                   } 
                   else
                   {
                      //displaying an error message if any
                   	  echo 'error '.mysqli_error($dbcon);
                   }
		   }
      }
  	 

     







?>





   <!-- section body -->
    
       <section id="into-body">
       	   <div class="container">
       	   	  <div class="row">

                

                   
                   <!-- form  to  add  staff -->
                   <div class="col-md-3"></div>
                     <div class="col-md-6">

                              
                          <div class="panel panel-primary">
                            <div class="panel-heading">
                              <h2 class="panel-title">Add Staff History Of Services</h2>
                            </div>
                          <div class="panel-body">
                            
                              <?php if(!empty($msg)) :?> 
                               <?php echo $msg; ?>
                              <?php endif; ?>

                            <form action="h.php?staff_id=<?php echo $staff_id; ?>" method="POST" class="form-group">  



                             <div class="row">
                              <div class="col-md-12">
                                 <label>Date Of Appointment</label>
                                <input class="form-control" type="text" name="h_date" placeholder="Appointment Date">
                              </div>
                            </div>	
                             
                              <br>

                             <div class="row">
                              <div class="col-md-12">
                                 <label>Type Of Appointment</label>
                                <input class="form-control" type="text" name="h_type" placeholder="Type of Appointment">
                              </div>
                            </div>


                             <br> 

                             <div class="row">
                             
                              <div class="col-md-12">
                                 <label>Apointment Details</label>
                                <textarea class="form-control" name="h_detail" placeholder="Apointment Details"></textarea>
                              </div>
                              
                            </div>

                            <br>

                             <div class="row">
                              <div class="col-md-4"></div>
                              <div class="col-md-4"></div>

                              <div class="col-md-4">
                                 <input type="submit" class="btn btn-success pull-right" value="+ Save Data" />
                              </div>

                            </div>

                            
                       </form><!-- end of form -->
 
                            

                          </div><!-- end of panel body -->
                        </div><!-- end of panel default -->
                          
                        

                     </div>
                     <div class="col-md-3"></div>
                   <!-- form to add  staff -->           
                   

                  

       	   	  </div>
       	   </div>
       </section>

    <!--/ section body -->